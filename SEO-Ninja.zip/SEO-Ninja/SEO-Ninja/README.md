# SEO Ninja Linking Spot Finder

Petit outil Node.js pour trouver des spots de ninja linking en FR.
- Lancez `npm install`
- Puis `npm start`
- Interface dispo sur http://localhost:3000